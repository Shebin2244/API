package karatetestrunner;

import com.intuit.karate.junit5.Karate;

public class TestRunner {
    // Method to execute Karate tests
    @Karate.Test
    Karate Karatetest() {
        // Run the Karate test defined in AutherFeature.feature
        return Karate.run("classpath:PostsFeature.feature").relativeTo(getClass());
    }
}
