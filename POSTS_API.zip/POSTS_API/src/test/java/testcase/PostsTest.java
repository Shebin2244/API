
package testcase;

import static org.testng.Assert.assertEquals;

import java.io.File;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.EndPoints;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import payloads.PostsModel;
import utilities.ExtentReportManager;

@Listeners(ExtentReportManager.class)
public class PostsTest {

	private PostsModel posts;

	@BeforeClass
	public void setup() {
		// Initialize PostsModel objects
		posts = new PostsModel();
		// Generate values for posts attributes
		posts.setTitle("OnePiece 2");
		posts.setContent("Adventure");
		posts.setSlug("onepiece-2");
		posts.setPicture("https://example.com/image.jpg");
		posts.setUser(5);

	}

	// Test method to create a post
	@Test(priority = 0)
	public void testCreatePosts() {
		Response response = EndPoints.createPosts(posts);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 201);
	}

	// Test method to get all posts
	@Test(priority = 1)
	public void testGetAllPosts() {
		Response response = EndPoints.getAllPosts();
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);

	}

	// Test method to get a single posts
	@Test(priority = 2)
	public void testGetSinglePosts() {
		Response response = EndPoints.getSinglePostswithId(2);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}

	// Test method to update a post
	@Test(priority = 3)
	public void testUpdatePosts() {
		File payload = new File(System.getProperty("user.dir") + "/src/main/resources/payload/payload.json");
		Response response = EndPoints.updatePosts(payload,43);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}

	// Test method to delete a post
	@Test(priority = 4)
	public void testDeletePosts() {
		Response response = EndPoints.deletePosts(4);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
}
