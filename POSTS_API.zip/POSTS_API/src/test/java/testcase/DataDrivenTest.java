package testcase;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.EndPoints;
import io.restassured.response.Response;
import payloads.PostsModel;
import utilities.DataProviders;
import utilities.ExtentReportManager; // Importing the ExtentReportManager listener

// Adding the ExtentReportManager listener to this class
@Listeners(ExtentReportManager.class)
public class DataDrivenTest {

    // Test method to create posts using data from Excel
    @Test(priority = 1, dataProvider = "Exceldata", dataProviderClass = DataProviders.class)
    public void testCreatingPostsFromExcel(String title, String content, String slug,String picture, String user) {
        // Creating an instance of PostsModel with data from Excel
    	int userid=Integer.parseInt(user);
        PostsModel posts = new PostsModel();
        posts.setTitle(title);
		posts.setContent(content);
		posts.setSlug(slug);
		posts.setPicture(picture);
		posts.setUser(userid);
        
        // Sending POST request to create posts
        Response response = EndPoints.createPosts(posts);
        
        // Logging the response
        response.then().log().all();
        
        // Asserting that the status code is 200
        Assert.assertEquals(response.getStatusCode(), 201);
    }
}
