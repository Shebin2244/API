package endpoints;

import java.io.File;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payloads.PostsModel;

public class EndPoints {
	

	
    // Method to create an tutorial
    public static Response createPosts(PostsModel payload) {
        // Allowing relaxed HTTPS validation
        RestAssured.useRelaxedHTTPSValidation();
        // Sending POST request to create an tutorial
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
//                .header("Authorization", "Bearer " + bearerToken)
                .baseUri(Routes.BASE_URI)
                .basePath(Routes.POST_BASE_PATH)
                .accept(ContentType.JSON)
                .body(payload)
                .when()
                .post();
        return response;
    }

    // Method to get all tutorials
    public static Response getAllPosts() {
        RestAssured.useRelaxedHTTPSValidation();
        // Sending GET request to retrieve all tutorials
        Response response = RestAssured.given()
                .baseUri(Routes.BASE_URI)
                .basePath(Routes.GET_BASE_PATH)
                .accept(ContentType.JSON)
                .when()
                .get();
        return response;
    }

    // Method to get a single tutorial by ID
    public static Response getSinglePostswithId(int id) {
        RestAssured.useRelaxedHTTPSValidation();
        // Sending GET request to retrieve a single tutorial by ID
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Routes.BASE_URI)
                .basePath(Routes.GET_BASE_PATH_POSTS)
                .pathParam("id", id)
                .accept(ContentType.JSON)
                .when()
                .get();
        return response;
    }



    // Method to update an tutorial by ID
    public static Response updatePosts(File payload,int i) {
        RestAssured.useRelaxedHTTPSValidation();

        RestAssured.useRelaxedHTTPSValidation();
        // Sending PUT request to update an tutorial by ID
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Routes.BASE_URI)
                .basePath(Routes.GET_BASE_PATH_POSTS)
                .pathParam("id", i)
                .accept(ContentType.JSON)
                .body(payload)
                .when()
                .put();
        return response;
    }

    // Method to delete an tutorial by ID
    public static Response deletePosts(int id) {
        RestAssured.useRelaxedHTTPSValidation();
        // Sending DELETE request to delete an tutorial by ID
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Sever", "Kestrel") // Typo: "Server" instead of "Sever"
                .baseUri(Routes.BASE_URI)
                .basePath(Routes.GET_BASE_PATH_POSTS)
                .pathParam("id", id)
                .when()
                .delete();
        return response;
    }

	public static Response createPostsUsingPayload(File payload) {
		 // Allowing relaxed HTTPS validation
        RestAssured.useRelaxedHTTPSValidation();
        // Sending POST request to create an tutorial
        Response response = RestAssured.given()
                .header("Content-Type", "application/json", "Accept", ContentType.JSON)
                .baseUri(Routes.BASE_URI)
                .basePath(Routes.POST_BASE_PATH)
                .accept(ContentType.JSON)
                .body(payload)
                .when()
                .post();
        return response;
	}
}
