package endpoints;

public class Routes {
	// Base URI for the API
	public static String BASE_URI = "https://freefakeapi.io/";

	// Endpoint for getting all 
	public static String GET_BASE_PATH = "api/posts";

	// Endpoint for getting a single posts by ID
	public static String GET_BASE_PATH_POSTS = "api/posts/{id}";


	// Endpoint for creating a new posts
	public static String POST_BASE_PATH = "api/posts";

	// Endpoint for updating an posts by ID
	public static String UPDATE_BASE_PATH_POSTS = "api/posts/{id}";

	// Endpoint for deleting an posts by ID
	public static String DELETE_BASE_PATH_POSTS = "api/posts/{id}";
}
