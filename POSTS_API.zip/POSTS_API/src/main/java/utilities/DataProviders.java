package utilities;

import org.testng.annotations.DataProvider;

public class DataProviders {

    // This method provides data from an Excel file for TestNG tests
    @DataProvider(name = "Exceldata")
    public String[][] getData() {
        // Path to the Excel file
        String path = System.getProperty("user.dir") + "//ExcelTestData//PostsData.xlsx";
        // Name of the Excel sheet
        String SheetName = "Sheet1";
        
        // Create an instance of XLutility to work with Excel file
        XLutility xl = new XLutility(path, SheetName);
        
        // Get the number of rows in the Excel sheet
        int rowCount = xl.GetRowCount();
        // Get the number of columns in the Excel sheet
        int colCount = xl.GetCellCount(rowCount);
        
        // Create a 2D array to store the data from Excel sheet
        String[][] arr = new String[rowCount][colCount];
        
        // Iterate through each row and column to fetch the data
        for(int i = 1; i <= rowCount; i++) {
            for(int j = 0; j < colCount; j++) {
                // Get data from each cell and store it in the array
                arr[i - 1][j] = xl.GetCellData(i, j);
            }
        }
        
        // Return the 2D array containing the Excel data
        return arr;
    }
}
