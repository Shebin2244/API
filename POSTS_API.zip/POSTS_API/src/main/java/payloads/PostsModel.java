package payloads;

public class PostsModel {

    // Attributes of the PostsModel class
    private String id;
    private String title;
    private String content;
    private String slug;
    private String picture;
    private int user;

    
    // Default constructor
    public PostsModel() {
        
    }
    
    // Parameterized constructor
    public PostsModel(String id, String title, String content, String slug, String picture, int user, String selfLink, String modifyLink, String deleteLink) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.slug = slug;
        this.picture = picture;
        this.user = user;
      
    }
    
    // Getter for id
    public String getId() {
        return id;
    }
    
    // Setter for id
    public void setId(String id) {
        this.id = id;
    }
    
    // Getter for title
    public String getTitle() {
        return title;
    }
    
    // Setter for title
    public void setTitle(String title) {
        this.title = title;
    }
    
    // Getter for content
    public String getContent() {
        return content;
    }
    
    // Setter for content
    public void setContent(String content) {
        this.content = content;
    }
    
    // Getter for slug
    public String getSlug() {
        return slug;
    }
    
    // Setter for slug
    public void setSlug(String slug) {
        this.slug = slug;
    }
    
    // Getter for picture
    public String getPicture() {
        return picture;
    }
    
    // Setter for picture
    public void setPicture(String picture) {
        this.picture = picture;
    }
    
    // Getter for user
    public int getUser() {
        return user;
    }
    
    // Setter for user
    public void setUser(int i) {
        this.user = i;
    }
    
   
    // Override toString method to  the PostsModel object
    @Override
    public String toString() {
        return "PostsModel {id='" + id + "', title='" + title + "', content='" + content + "', slug='" + slug + "', picture='" + picture + "', user='" + user + "'}";
    }
}


















